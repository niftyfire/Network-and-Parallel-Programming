import java.net.*;

public class updClient {

	public static void main(String[] args) {
		
		int i = 0;
		byte[] data = "Hey! this is a message from clint.".getBytes();
		byte[] data1 = "LastPacket.".getBytes();
		
		DatagramPacket packet = new DatagramPacket(data, data.length);
		
		try {
			
			InetAddress address = InetAddress.getByName("SaNa-PC");
			packet.setAddress(address);
			packet.setPort(9800);
			
			DatagramSocket socket = new DatagramSocket();			
			while(i < 10) {

				socket.send(packet);
				i++;
			}
			
			socket.send(new DatagramPacket(data1, 0, data1.length));
			
			socket.close();
			
		} catch (Exception e) {
			
			System.out.println("Failed to get Address");
			
		}
	}

}