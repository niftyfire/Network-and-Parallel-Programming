import java.io.*;

public class FileInputStreamDemo {

	public static void main(String[] args) {
		
		String filename = "D:\\ProgrammingProjects\\NetworksAndParallelProgramming\\FileInputStreamDemo\\FileInputStream.txt";
		String filename2 = "D:\\ProgrammingProjects\\NetworksAndParallelProgramming\\FileInputStreamDemo\\FileOutputStream.txt";
		
		try {
			
			InputStream fileinput = new FileInputStream(filename);
			OutputStream fileoutput = new FileOutputStream(filename2);
			
			int data = fileinput.read();
			fileoutput.write(data);
			
			while (data != -1) {
				
				System.out.print(Character.toChars(data));
				data = fileinput.read();
				
				if (fileinput.available() > 0)
					fileoutput.write(data);				
			}
			
			fileinput.close();
			
		} catch (FileNotFoundException e) {
			
			System.out.println("File Not Found");
			
		} catch (IOException e) {
			
			System.out.println(e);
			
		}

	}

}
