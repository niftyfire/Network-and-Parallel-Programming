import java.io.*;
import java.io.ObjectInputStream.GetField;
import java.net.*;

public class portscaner {

	public static void main(String[] args) {
		
		String localhost = "localhost";
		ScanePort(localhost);

	}
	
	private static void ScanePort(String localhost) {

		for (int port = 0; port < 65536 ; port++) {
			
			try {
				Socket testScoket = new Socket(localhost, port);
				System.out.println("Port #" + port + " is found open on server " + localhost);
				testScoket.close();
				
			} catch (IOException exc) {
				System.out.println("Port Closed");
			}			
		}
	}

}
