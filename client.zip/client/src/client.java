import java.net.*;
import java.io.*;

public class client {

	public static void main(String[] args) {
		
		String servername = "SaNa-PC";
		int port = 5000;
		
		try {
			
			Socket clientsocket = new Socket(servername, port);
			DataOutputStream out = new DataOutputStream(clientsocket.getOutputStream());			
			out.writeUTF("Hey! Server "+servername+" from "+clientsocket.getLocalSocketAddress()+"\n");
			
			DataInputStream in = new DataInputStream(clientsocket.getInputStream());
			System.out.println("Message from server: \n " + in.readUTF());
			
			in.close();
			out.close();
			clientsocket.close();
			
		} catch (IOException e) {
			
			System.out.println("Client Socket connecion establishment failed");
		}
	}

}
