import java.io.*;
import java.net.*;

public class serverSocket {

	public static void main(String[] args) {
		
		DataOutputStream outStream;
		DataInputStream inStream;
		String msg = "";
		
		try {
			ServerSocket servSoc = new ServerSocket(3266);
			
			Socket client = servSoc.accept();
			
			outStream = new DataOutputStream(client.getOutputStream());
//			inStream = new DataInputStream(client.getInputStream());
			
//			msg = inStream.readLine();
			
//			System.out.println("Message From Client " + msg );
			outStream.writeUTF("Hey! thr...!!");
			
			outStream.close();
			client.close();			
			
		} catch (IOException ex) {
			System.out.println("Server Socket Failed");
		}
		
	}

}
