import java.net.*;
import java.io.*;

public class server {
	
	public static void main(String[] args) {
		
		try {
			
			ServerSocket listener = new ServerSocket(3673);
			int i = 1;
			
			while(true) {
				
				// New client
				Socket clientSocket = listener.accept();
				
				// Message from Client
				System.out.println("Client number " + i);
				DataInputStream in = new DataInputStream(clientSocket.getInputStream());
				System.out.println("Message from Client "+i+ ":" );
				System.out.println(in.readUTF());
				
				// Reply from Server
				DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
				out.writeUTF("Hey! Client " + i +"\n Thankyou for Connection\n");
				
				in.close();
				out.close();
				clientSocket.close();
				i++;
			}
			
		} catch (IOException e) {
			System.out.println("Server Socket failed To establish connection");
		}				
	}

}
