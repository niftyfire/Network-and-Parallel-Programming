import java.io.Serializable;

public class Student implements Serializable {
	
	private int rollNum;
	private String name;
	private int age;
	private  String pass;
	
	public Student (int r, String n, int a, String p) {		
		rollNum = r;
		name = n;
		age = a;
		pass = p;
	}
	
	public String getName() {
		return name;
	}
	
	public int getRoll() {
		return rollNum;
	}
	
	public int getAge() {
		return age;
	}
	
	public String getPass() {
		return pass;
	}
}
