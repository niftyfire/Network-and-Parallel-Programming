import java.io.*;

public class serializing {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		Student std1 = new Student(110607, "Danyal", 22, "abc");
		Student std2 = new Student(110608, "Asad", 22, "abcd");
		Student std3 = new Student(110609, "musa", 22, "abcde");
		
		ObjectOutputStream outstream = new ObjectOutputStream(new FileOutputStream("students.dat"));
		
			try {
				
				writeObject(outstream, std1);
				writeObject(outstream, std2);
				writeObject(outstream, std3);
				
			} catch (Exception e) {
				System.out.println("End of file");
			}
		
		outstream.close();
		
		String filename = "students.dat";
		readObjects(filename);
	}
	
	public static void writeObject(ObjectOutputStream oos, Student obj) throws Exception {
			oos.writeObject(obj);
	}
	
	public static void readObjects(String filename) throws FileNotFoundException, IOException {
		
		ObjectInputStream inputstream  = new ObjectInputStream(new FileInputStream(filename));
		
		try {				
		
			do {
				Student student = (Student)inputstream.readObject();
				System.out.print(student.getRoll()+ " ");
				System.out.print(student.getName()+ " ");
				System.out.println(student.getAge()+ " ");
				System.out.println(student.getPass());
				
			} while (true);
			
			
		} catch (EOFException e) {
			
			System.out.println("End of File");
			inputstream.close();
			
		} catch (IOException ioe) {
			
			System.out.println("End of File");
			
		} catch (ClassNotFoundException cnfe) {
			
			System.out.println("Class not ");
		}
	}
}
