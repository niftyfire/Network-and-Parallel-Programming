import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Designer {

	private JFrame frame;
	private JTextField rollnumber;
	private JTextField stdname;
	private JTextField stdage;
	private JTextField password;
	
	Student std;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public Designer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JLabel lblRollNumber = new JLabel("Roll Number");
		GridBagConstraints gbc_lblRollNumber = new GridBagConstraints();
		gbc_lblRollNumber.insets = new Insets(0, 0, 5, 5);
		gbc_lblRollNumber.gridx = 3;
		gbc_lblRollNumber.gridy = 1;
		frame.getContentPane().add(lblRollNumber, gbc_lblRollNumber);
		
		rollnumber = new JTextField();
		GridBagConstraints gbc_rollnumber = new GridBagConstraints();
		gbc_rollnumber.insets = new Insets(0, 0, 5, 5);
		gbc_rollnumber.fill = GridBagConstraints.HORIZONTAL;
		gbc_rollnumber.gridx = 5;
		gbc_rollnumber.gridy = 1;
		frame.getContentPane().add(rollnumber, gbc_rollnumber);
		rollnumber.setColumns(10);
		
		JLabel lblName = new JLabel("Name");
		GridBagConstraints gbc_lblName = new GridBagConstraints();
		gbc_lblName.insets = new Insets(0, 0, 5, 5);
		gbc_lblName.gridx = 3;
		gbc_lblName.gridy = 2;
		frame.getContentPane().add(lblName, gbc_lblName);
		
		stdname = new JTextField();
		GridBagConstraints gbc_stdname = new GridBagConstraints();
		gbc_stdname.insets = new Insets(0, 0, 5, 5);
		gbc_stdname.fill = GridBagConstraints.HORIZONTAL;
		gbc_stdname.gridx = 5;
		gbc_stdname.gridy = 2;
		frame.getContentPane().add(stdname, gbc_stdname);
		stdname.setColumns(10);
		
		JLabel lblAge = new JLabel("Age");
		GridBagConstraints gbc_lblAge = new GridBagConstraints();
		gbc_lblAge.insets = new Insets(0, 0, 5, 5);
		gbc_lblAge.gridx = 3;
		gbc_lblAge.gridy = 3;
		frame.getContentPane().add(lblAge, gbc_lblAge);
		
		stdage = new JTextField();
		GridBagConstraints gbc_stdage = new GridBagConstraints();
		gbc_stdage.insets = new Insets(0, 0, 5, 5);
		gbc_stdage.fill = GridBagConstraints.HORIZONTAL;
		gbc_stdage.gridx = 5;
		gbc_stdage.gridy = 3;
		frame.getContentPane().add(stdage, gbc_stdage);
		stdage.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
		gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
		gbc_lblPassword.gridx = 3;
		gbc_lblPassword.gridy = 4;
		frame.getContentPane().add(lblPassword, gbc_lblPassword);
		
		password = new JTextField();
		GridBagConstraints gbc_password = new GridBagConstraints();
		gbc_password.insets = new Insets(0, 0, 5, 5);
		gbc_password.fill = GridBagConstraints.HORIZONTAL;
		gbc_password.gridx = 5;
		gbc_password.gridy = 4;
		frame.getContentPane().add(password, gbc_password);
		password.setColumns(10);
		
		JButton btnAddStudent = new JButton("Add Student");
		btnAddStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Student std = new Student(2, "ass" ,2 ,"we");
				
			}
		});
		GridBagConstraints gbc_btnAddStudent = new GridBagConstraints();
		gbc_btnAddStudent.insets = new Insets(0, 0, 5, 5);
		gbc_btnAddStudent.gridx = 5;
		gbc_btnAddStudent.gridy = 6;
		frame.getContentPane().add(btnAddStudent, gbc_btnAddStudent);
		
		JButton btnReadStudent = new JButton("Read Student");
		GridBagConstraints gbc_btnReadStudent = new GridBagConstraints();
		gbc_btnReadStudent.insets = new Insets(0, 0, 0, 5);
		gbc_btnReadStudent.gridx = 5;
		gbc_btnReadStudent.gridy = 7;
		frame.getContentPane().add(btnReadStudent, gbc_btnReadStudent);
	}

}
