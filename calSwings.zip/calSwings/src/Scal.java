import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Scal {
	
	JFrame mainframe;
	JPanel controlsPanel;
	JPanel inputPanel;
	JPanel opPanel;
	JTextField inputbox;
	String input1 = "";

	public Scal(){
		prepareCAL();
	}

	public static void main(String[] args) {
		Scal cal = new Scal();
		cal.showcontrols();
	}

	private void prepareCAL() {
		mainframe = new JFrame();
		mainframe.setSize(400, 400);
		mainframe.setBackground(Color.GRAY);		
		
		inputPanel = new JPanel(); 
		controlsPanel = new JPanel();
		controlsPanel.setSize(new Dimension(200, 250));
		
		opPanel = new JPanel();
		opPanel.setSize(200, 250);
//		opPanel.setMaximumSize(new Dimension(200, 250));

		mainframe.add(inputPanel, BorderLayout.NORTH);
		mainframe.add(controlsPanel, BorderLayout.CENTER);
		mainframe.add(opPanel, BorderLayout.EAST);
		mainframe.setVisible(true);
	}
	
	private void showcontrols() {
		inputbox = new JTextField(30);
		inputbox.setText("");
		
		inputPanel.add(inputbox);
		
		JButton btn1 = new JButton("1");
		btn1.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("1");
		
		JButton btn2 = new JButton("2");
		btn2.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("2");
		
		JButton btn3 = new JButton("3");
		btn3.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("3");
		
		JButton btn4 = new JButton("4");
		btn4.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("4");
		
		JButton btn5 = new JButton("5");
		btn5.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("5");
		
		JButton btn6 = new JButton("6");
		btn6.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("6");
		
		JButton btn7 = new JButton("7");
		btn7.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("7");
		
		JButton btn8 = new JButton("8");
		btn8.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("8");
		
		JButton btn9 = new JButton("9");
		btn9.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("9");
		
		JButton btnclear = new JButton("C");
		btnclear.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("c");
		
		JButton btn0 = new JButton("0");
		btn0.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("0");
		
		JButton btnequal = new JButton("=");
		btnequal.setPreferredSize(new Dimension(50, 50));
		btn1.setActionCommand("=");
		
		controlsPanel.add(btn1);
		controlsPanel.add(btn2);
		controlsPanel.add(btn3);
		controlsPanel.add(btn4);
		controlsPanel.add(btn5);
		controlsPanel.add(btn6);		
		controlsPanel.add(btn7);
		controlsPanel.add(btn8);
		controlsPanel.add(btn9);
		controlsPanel.add(btnclear);
		controlsPanel.add(btn0);
		controlsPanel.add(btnequal);
		
		JButton btnPlus = new JButton("+");
		btnPlus.setPreferredSize(new Dimension(50, 50));
		btnPlus.setActionCommand("+");
		
		JButton btnSub = new JButton("-");
		btnSub.setPreferredSize(new Dimension(50, 50));
		btnSub.setActionCommand("-");
		
		JButton btnMul = new JButton("*");
		btnMul.setPreferredSize(new Dimension(50, 50));
		btnMul.setActionCommand("*");
		
		JButton btnDiv = new JButton("/");
		btnDiv.setPreferredSize(new Dimension(50, 50));
		btnDiv.setActionCommand("/");
		
		btn1.addActionListener(new ClickListener());
		btn2.addActionListener(new ClickListener());
		btn3.addActionListener(new ClickListener());
		btn4.addActionListener(new ClickListener());
		btn5.addActionListener(new ClickListener());
		btn6.addActionListener(new ClickListener());
		btn7.addActionListener(new ClickListener());
		btn8.addActionListener(new ClickListener());
		btn9.addActionListener(new ClickListener());
		btn0.addActionListener(new ClickListener());
		btnPlus.addActionListener(new ClickListener());
		btnSub.addActionListener(new ClickListener());
		btnMul.addActionListener(new ClickListener());
		btnDiv.addActionListener(new ClickListener());
		btnclear.addActionListener(new ClickListener());
		btnequal.addActionListener(new ClickListener());
		
		
		opPanel.add(btnPlus);
		opPanel.add(btnSub);
		opPanel.add(btnMul);
		opPanel.add(btnDiv);
		mainframe.setVisible(true);		
	}
	
	private class ClickListener implements ActionListener {
		
		@Override
		public void actionPerformed(ActionEvent e) {
									
			if ("1".equals(e.getActionCommand())){
				inputbox.setText("1");
			}
			
		}
	}
	
}
