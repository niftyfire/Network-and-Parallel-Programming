import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class testSwing {
	
	private JFrame mainframe;
	private JLabel heading;
	private JLabel status;
	private JPanel controlpanel;
	
	public testSwing () {
		prepareGUI();
	}
	
	public static void main(String[] args) {
		testSwing swingtest = new testSwing();
		swingtest.showcontrols();
	}
	
	private void prepareGUI() {
		// main frame
		mainframe = new JFrame();
		mainframe.setSize(400, 400);
		mainframe.setLayout(new GridLayout(3, 1));
		
		// header and status label
		heading = new JLabel("", JLabel.CENTER);
		status = new JLabel("", JLabel.CENTER);
		status.setSize(200, 200);
		
		controlpanel = new JPanel();
		controlpanel.setLayout(new FlowLayout());
		
		mainframe.add(heading);
		mainframe.add(controlpanel);
		mainframe.add(status);
		mainframe.setVisible(true);		
	}
	
	private void showcontrols() {
		heading.setText("Test Swing Program");
		
		JButton okBtn = new JButton("OK");
		JButton submitBtn = new JButton("Submit");
		JButton cancelBtn = new JButton("Cancel");
		
		okBtn.setActionCommand("ok");
		submitBtn.setActionCommand("submit");
		cancelBtn.setActionCommand("cancel");
		
		okBtn.addActionListener( new ClickListener());		
		submitBtn.addActionListener(new ClickListener());
		cancelBtn.addActionListener(new ClickListener());
		
		controlpanel.add(okBtn);
		controlpanel.add(submitBtn);
		controlpanel.add(cancelBtn);
	}
	
	private class ClickListener implements ActionListener{
		
		public void actionPerformed(ActionEvent e){
			String value = e.getActionCommand();
			if (value.equals("ok")) {
				status.setText("OK Pressed");
			} else if (value.equals("submit")) {
				status.setText("Submit Pressed");
			} else if (value.equals("cancel")) {
				status.setText("Cancel Pressed");
			}
		}
	}
	
}