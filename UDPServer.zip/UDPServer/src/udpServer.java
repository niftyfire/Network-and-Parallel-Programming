import java.net.*;

public class udpServer {

	public static void main(String[] args) {

		int i = 0;
		byte[] data = new byte[1500];
		DatagramPacket packet = new DatagramPacket(data, data.length);
		
		try {
			
			DatagramSocket socket = new DatagramSocket(3264);
			
			while (i  < 101) {
				
				socket.receive(packet);
				if ((new String(packet.getData(), 0 , packet.getLength())) == "LastPacket")
					break;
				i++;
			}
			
			socket.close();
			System.out.println("Total Packets Recieved are" + i+"\n");			
			String dataInString = new String(packet.getData(), 0, packet.getLength());			
			System.out.println("Message from Cient\n"+dataInString);
			
		} catch (Exception e) {
			
			System.out.println("Exception");
			
		}
		
				
	}

}
