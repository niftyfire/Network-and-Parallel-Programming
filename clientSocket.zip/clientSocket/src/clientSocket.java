import java.io.*;
import java.net.*;

public class clientSocket {

	public static void main(String[] args) {
		
		DataInputStream inStream;
		DataOutputStream outStream;
		String msg = "";
		
		try {
			
			Socket client = new Socket("SaNa-PC", 5000);
			
			inStream = new DataInputStream(client.getInputStream());
			outStream = new DataOutputStream(client.getOutputStream());
			
			outStream.writeUTF("Client: Hey there..." );			
			msg = inStream.readUTF();
			System.out.println("Message from Server: " + msg);
			
			client.close();
			inStream.close();
			
		} catch (IOException exc)
		{
			System.out.println("Client Socket Failed");
		}
		
	}

}
