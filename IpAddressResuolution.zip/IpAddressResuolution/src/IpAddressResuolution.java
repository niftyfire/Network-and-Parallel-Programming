import java.net.*;


public class IpAddressResuolution {

	public static void main(String[] args) {
		
		try {
			
			InetAddress address = InetAddress.getByName("www.google.com");
			System.out.println(address);
			
		} catch (UnknownHostException e) {
			
			System.out.println("Sorry Could not translate to IP Address");
		
		}
	}
}